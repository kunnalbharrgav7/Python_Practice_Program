

a =float(input("भाईसाहब!  कुछ नंबर दो :"))
x=a%2
print(x)
print(type(a))
if a==0:
   print("क्या करते हो भाईसाहब कुछ अच्छा नंबर दो 😎" )
   print("Not even nor Odd")
   
elif a%2==0:
   print("बहुत शानदार प्रदर्शन भाईसाहब लगे रहो  😎" )
   print("Even number")

else:
    print("odd number")
print("धन्यवाद भाईसाहब 😎👍😎")
