print("राम राम चाचा (☞ﾟヮﾟ)☞🌞🔥")
for i in range(1, 11):
    print(i)
print("अच्छा अब चलते हैं चाचा राधे राधे 😎😁😃👀👍✌")

for i in range(5):
    print(i)
table = int(input("चाचा पढाई करें अब नंबर दो :  "))
for i in range(1, 11):
    print(table, " *", i, " = ", table*i)
count = 1
for i in range(1, 11):
    print("{}*{}={}".format(table, i, table*i))
    count += 1
    print(f"{table}*{i}={table*i}")
