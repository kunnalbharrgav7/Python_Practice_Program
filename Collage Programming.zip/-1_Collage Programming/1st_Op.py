# write a python script to add 2 numbers

a = 2345
b = 6789
c = a+b
print(c)

# write a python script to divide  2 numbers

a = 2345
b = 0
# c=a/b
# print(c)


a = 10
b = 2
c = a//b
print(c)


print(a)

a += 5

print(a)

b = 6
print(a < b)
