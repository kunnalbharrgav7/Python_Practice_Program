def user_input():
    # a= int(input("enter value 1 "))
    # b=int(input("enter value 2 "))
    a,b= int(input("Enter val 1 :")), int(input("Enter val 2 :"))
    
    return (a,b)
def add(a,b):
    return a+b
a,b = user_input()
#add(a,b)
print(add(a,b))




#----------------------- Error in this program \
#   Name Error  

