# Date 7 March 2022
# 
# import math 
# x=4 
# y=math.sqrt(x)
# print(x)
# print(y)

#  2nd Way 
#  import math as m 
# x=4 
# y=m.sqrt(x)
# print(x)
# print(y)

#    3rd way


from  math import sqrt
x=4 
y=sqrt(x)
print(x)
print(y)

r = float(input("Enter radius :"))
print("Area of radius ", r , " is : " , 3.14*r*r)
area= (3.14 *r*r)
area=round(area,4)
print("Area of radius ", r , " is : " , area)

